<template>
	<view class="content">
		<view class="list">
			<view class="list_item" v-for="(item,index) in data" :key="index">
				<image class="logo" src="/static/logo.png"></image>
				<view>{{item.content}}</view>

			</view>
		</view>


	</view>
</template>

<script setup>
	import {
		ref
	} from 'vue';

	const data = ref([{
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, {
		path: '/static/logo.png',
		content: '标题内容内容内容内容内容内容内容内容内容内容内容内容内容'
	}, ])
</script>

<style lang="scss" scoped>
	.logo {
		width: 30px;
		height: 30px;
	}

	.list_item {
		display: flex;
		align-items: center;
		justify-content: center;
		border-bottom: 1px solid blanchedalmond;
		margin: 20px 10px;
	}
</style>